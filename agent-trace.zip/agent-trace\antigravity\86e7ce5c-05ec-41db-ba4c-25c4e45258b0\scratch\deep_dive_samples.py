import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')

def get_user_identifiers(req_email):
    # Match by current email
    curr = identities[identities['email'].str.lower() == req_email.lower()]
    if len(curr) > 0:
        uid = curr.iloc[0]['user_id']
    else:
        # Match in audit log
        hist = audit_log[(audit_log['old_value'].str.lower() == req_email.lower()) | (audit_log['new_value'].str.lower() == req_email.lower())]
        if len(hist) > 0:
            uid = hist.iloc[0]['user_id']
        else:
            return None, set()
    
    # Collect all emails, phones, hashes, names
    u_row = identities[identities['user_id'] == uid]
    emails = set()
    phones = set()
    hashes = set()
    names = set()
    if len(u_row) > 0:
        r = u_row.iloc[0]
        if pd.notna(r['email']): emails.add(r['email'].lower())
        if pd.notna(r['phone']): phones.add(r['phone'])
        if pd.notna(r['email_hash']): hashes.add(r['email_hash'])
        if pd.notna(r['name']): names.add(r['name'])
    
    u_audits = audit_log[audit_log['user_id'] == uid]
    for _, ar in u_audits.iterrows():
        fn = ar['field_name']
        if fn == 'email':
            if pd.notna(ar['old_value']): emails.add(ar['old_value'].lower())
            if pd.notna(ar['new_value']): emails.add(ar['new_value'].lower())
        elif fn == 'phone':
            if pd.notna(ar['old_value']): phones.add(ar['old_value'])
            if pd.notna(ar['new_value']): phones.add(ar['new_value'])
        elif fn == 'name':
            if pd.notna(ar['old_value']): names.add(ar['old_value'])
            if pd.notna(ar['new_value']): names.add(ar['new_value'])
            
    return uid, {"emails": emails, "phones": phones, "hashes": hashes, "names": names}

for idx in range(1, 11):
    cid = f"case_{idx:02d}"
    req = samples[samples['case_id'] == cid].iloc[0]
    out = sample_out[sample_out['case_id'] == cid].iloc[0]
    uid, id_dict = get_user_identifiers(req['email'])
    print(f"\n==================== {cid} ====================")
    print(f"Req: email={req['email']}, reported_status={req['reported_status']}, audit_at={req['audit_at']}")
    print(f"Resolved UID: {uid}, emails={id_dict.get('emails', set())}")
    print(f"Ground Truth Status: {out['deletion_status']}")
    gt_steps = json.loads(out['steps_json'])
    for s in gt_steps:
        print(f"  GT Step: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | {s['evidence_id']}")
    
    # Check activity log for this user or resources
    # Activity log has resource_id, let's see which activity rows match GT resources or user_id or emails
    gt_rids = [s['resource_id'] for s in gt_steps]
    user_acts = activity[activity['resource_id'].isin(gt_rids)]
    print(f"  Matching activities ({len(user_acts)}):")
    for _, a in user_acts.iterrows():
        print(f"    act: {a['activity_id']} | {a['event_time']} | {a['event_type']} | {a['source_system']} -> {a['target_system']} | {a['resource_id']} | {a['reported_result']}")
