import pandas as pd
import re

df = pd.read_csv('dataset/deletion_requests.csv', encoding='utf-8')

# Exclude the 4 non-deletion cases
remaining = df[~df['case_id'].isin(['case_533', 'case_535', 'case_540', 'case_541'])]

# Check if every single remaining case has a clear deletion intent word
keywords = [
    r'\bdelet\w*', r'\beras\w*', r'\bremov\w*', r'\bclos\w*', r'\bpurge\w*', r'\bforget\w*',
    r'suppression', r'supprimer', r'effacer',
    r'eliminaci', r'exclus',
    r'l[oö]schen', r'entfernen',
    r'cancellare', r'eliminare',
    r'削除', r'消去',
    r'삭제', r'탈퇴',
    r'注销', r'删除'
]
combined_pat = re.compile('|'.join(keywords), re.IGNORECASE)

unmatched = []
for i, r in remaining.iterrows():
    if not combined_pat.search(r['request_text']):
        unmatched.append((r['case_id'], r['request_text']))

print(f"Unmatched in remaining: {len(unmatched)}")
for c, t in unmatched:
    print(f"[{c}] -> {t}")
