import glob
import re

sql_files = sorted(glob.glob('dataset/evidence/databases/*.sql'))
print(f"Total SQL files: {len(sql_files)}")

for f in sql_files:
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        content = fp.read()
    tables = re.findall(r'CREATE TABLE\s+([^\s\(]+)', content, re.IGNORECASE)
    inserts = re.findall(r'INSERT INTO\s+([^\s\(]+)', content, re.IGNORECASE)
    captured = re.findall(r'Captured at:\s*([^\n\r]+)', content)
    print(f"{f}: captured={captured[0] if captured else 'None'}, tables={tables}, insert_counts={len(inserts)}")
