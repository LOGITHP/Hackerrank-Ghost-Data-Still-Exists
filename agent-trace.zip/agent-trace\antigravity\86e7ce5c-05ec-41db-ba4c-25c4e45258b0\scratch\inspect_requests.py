import pandas as pd

del_req = pd.read_csv('dataset/deletion_requests.csv')
print(f"Total deletion requests: {len(del_req)}")
print("Columns:", del_req.columns.tolist())
print("\nReported status distribution:")
print(del_req['reported_status'].value_counts())

# Check for keywords indicating deletion
texts = del_req['request_text'].tolist()
print("\nFirst 10 request texts:")
for i, t in enumerate(texts[:10]):
    print(f"[{i+1}] {t[:100]}")
