import pandas as pd
import json

df = pd.read_csv('test_sample_out.csv')
for cid in ['case_21', 'case_25', 'case_26', 'case_27', 'case_28']:
    r = df[df['case_id'] == cid].iloc[0]
    steps = json.loads(r['steps_json'])
    print(f"=== {cid} ===")
    for s in steps:
        print(f"  [{s['phase']}] sys={s['system_id']:18} rid={s['resource_id']:16} op={s['operation']:25} st={s['state']:10} ev={s['evidence_id']}")
