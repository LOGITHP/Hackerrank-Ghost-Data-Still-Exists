import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')

print(f"Total samples: {len(samples)}")

for i, row in sample_out.iterrows():
    case_id = row['case_id']
    status = row['deletion_status']
    steps = json.loads(row['steps_json'])
    req = samples[samples['case_id'] == case_id].iloc[0]
    email = req['email']
    audit_at = req['audit_at']
    resources = [(s['phase'], s['system_id'], s['resource_id'], s['operation'], s['state'], s['evidence_id']) for s in steps]
    print(f"\n[{case_id}] status={status} email={email} audit_at={audit_at}")
    for r in resources:
        print(f"   {r[0]:12} | {r[1]:20} | {r[2]:20} | {r[3]:25} | {r[4]:10} | {r[5]}")
