import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Parse timestamps
activity['dt'] = pd.to_datetime(activity['event_time'])

for idx in range(1, 16):
    cid = f"case_{idx:02d}"
    req = samples[samples['case_id'] == cid].iloc[0]
    out = sample_out[sample_out['case_id'] == cid].iloc[0]
    steps = json.loads(out['steps_json'])
    gt_rids = set(s['resource_id'] for s in steps)
    
    req_at = pd.to_datetime(req['requested_at'])
    rep_at = pd.to_datetime(req['reported_at'])
    aud_at = pd.to_datetime(req['audit_at'])
    
    # Check deletion_worker activities between requested_at - 1h and reported_at + 2h
    window_acts = activity[(activity['dt'] >= req_at - pd.Timedelta(hours=1)) & (activity['dt'] <= rep_at + pd.Timedelta(hours=2))]
    worker_acts = window_acts[window_acts['source_system'] == 'deletion_worker']
    
    found_rids = set(worker_acts['resource_id'].unique())
    
    print(f"\n{cid}: req_at={req['requested_at']} rep_at={req['reported_at']}")
    print(f"  GT resources: {gt_rids}")
    print(f"  Worker resources in window: {found_rids}")
    print(f"  Overlap: {gt_rids.intersection(found_rids)}")
    print(f"  GT not in window worker: {gt_rids - found_rids}")
