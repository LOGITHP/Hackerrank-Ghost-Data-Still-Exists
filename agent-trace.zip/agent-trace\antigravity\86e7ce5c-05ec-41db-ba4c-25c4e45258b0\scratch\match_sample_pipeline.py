import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

# Let's inspect for each case in sample_output how its exact resources correlate with:
# 1. Evidence items matching the user's identifiers
# 2. Deletion worker activities in the request window
for i, r in sample_out.iterrows():
    cid = r['case_id']
    req = samples[samples['case_id'] == cid].iloc[0]
    email = req['email']
    req_at = pd.to_datetime(req['requested_at'])
    rep_at = pd.to_datetime(req['reported_at'])
    aud_at = pd.to_datetime(req['audit_at'])
    
    gt_steps = json.loads(r['steps_json'])
    gt_rids = set(s['resource_id'] for s in gt_steps)
    
    # Check deletion worker activities in [req_at - 1h, rep_at + 2h]
    w_acts = activity[(activity['dt'] >= req_at - pd.Timedelta(hours=1)) & (activity['dt'] <= rep_at + pd.Timedelta(hours=2))]
    worker_acts = w_acts[w_acts['source_system'] == 'deletion_worker']
    
    # Look for account resource in worker acts
    acc_acts = worker_acts[worker_acts['target_system'] == 'account_service']
    
    print(f"\n{cid} ({req['reported_status']}): email={email} audit_at={req['audit_at']}")
    print(f"  GT rids ({len(gt_rids)}): {sorted(gt_rids)}")
    print(f"  Account acts in window: {acc_acts['resource_id'].tolist()}")
