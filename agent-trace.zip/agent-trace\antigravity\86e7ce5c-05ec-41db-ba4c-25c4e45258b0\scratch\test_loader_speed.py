import time
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..", "Downloads/Hackerrank/hackerrank-orchestrate-october26")))
os.chdir("c:/Users/logit/Downloads/Hackerrank/hackerrank-orchestrate-october26")

from code.ingestion.load_datasets import load_all_datasets
from code.ingestion.evidence_loader import EvidenceStore

t0 = time.time()
idx = load_all_datasets("dataset", use_sample=True)
print(f"Datasets loaded in {time.time() - t0:.2f}s")

store = EvidenceStore(idx.evidence_files_df, base_dir="dataset")
for _, r in idx.evidence_files_df.iterrows():
    p = r['file_path']
    full_path = os.path.join("dataset", p) if not os.path.isabs(p) else p
    t_f = time.time()
    sz = os.path.getsize(full_path) if os.path.exists(full_path) else 0
    print(f"Checking {r['file_id']}: {p} (size={sz} bytes)...")
    if p.endswith('.png'):
        print("  -> IMAGE file!")
