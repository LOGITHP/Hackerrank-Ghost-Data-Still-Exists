import pandas as pd
import json
import glob
import os
import re

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])
ev_files = pd.read_csv('dataset/evidence_files.csv')
ev_files['dt'] = pd.to_datetime(ev_files['captured_at'])

# Build identity lookup
id_to_uid = {}
uid_to_ids = {}
for _, r in identities.iterrows():
    uid = r['user_id']
    if uid not in uid_to_ids: uid_to_ids[uid] = set()
    uid_to_ids[uid].add(uid.lower())
    id_to_uid[uid.lower()] = uid
    for f in ['email', 'phone', 'name', 'email_hash']:
        v = r[f]
        if pd.notna(v):
            s = str(v).lower().strip()
            id_to_uid[s] = uid
            uid_to_ids[uid].add(s)

for _, a in audit_log.iterrows():
    uid = a['user_id']
    if uid not in uid_to_ids: uid_to_ids[uid] = set()
    for f in ['old_value', 'new_value']:
        v = a[f]
        if pd.notna(v):
            s = str(v).lower().strip()
            id_to_uid[s] = uid
            uid_to_ids[uid].add(s)

# Pre-parse all evidence files and index by user_id and email
print("Parsing evidence files...")
# user -> set of (system_id, resource_id, evidence_id, state_dict)
ev_user_records = {}

# 1. evidence_92
with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r') as fp:
    d92 = json.load(fp)
exports92 = d92.get('service_exports', {})

# Parse each section of ev92
for item in exports92.get('account_service', {}).get('profile_lookups', []):
    rid = item.get('resource_id')
    prof = item.get('profile')
    st_code = item.get('status_code')
    # If profile has email
    em = prof.get('email') if prof else None
    uid = id_to_uid.get(em.lower()) if em else None
    if uid:
        if uid not in ev_user_records: ev_user_records[uid] = []
        is_pres = (st_code == 200)
        ev_user_records[uid].append(('account_service', rid, 'evidence_92', {'is_present': is_pres}))

for item in exports92.get('security_service', {}).get('audit_records', []):
    rid = item.get('resource_id')
    u_ref = item.get('subject_reference')
    if u_ref and u_ref in uid_to_ids:
        if u_ref not in ev_user_records: ev_user_records[u_ref] = []
        ev_user_records[u_ref].append(('security_service', rid, 'evidence_92', {'is_present': True}))

for item in exports92.get('support_platform', {}).get('tickets', []):
    rid = item.get('resource_id')
    u_ref = item.get('customer_reference')
    if u_ref and u_ref in uid_to_ids:
        if u_ref not in ev_user_records: ev_user_records[u_ref] = []
        is_red = (item.get('requester_email') is None)
        ev_user_records[u_ref].append(('support_platform', rid, 'evidence_92', {'is_redacted': is_red, 'has_exposed_pii': not is_red}))

for item in exports92.get('analytics_platform', {}).get('profiles', []):
    rid = item.get('resource_id')
    # analytics profiles in ev92
    pass

for item in exports92.get('integration_service', {}).get('connectors', []):
    rid = item.get('resource_id')
    u_ref = item.get('customer_reference')
    if u_ref and u_ref in uid_to_ids:
        if u_ref not in ev_user_records: ev_user_records[u_ref] = []
        en = item.get('enabled', False)
        ev_user_records[u_ref].append(('integration_service', rid, 'evidence_92', {'is_flow_disabled': not en, 'has_active_flow': en}))

for item in exports92.get('backup_service', {}).get('restore_entries', []):
    rid = item.get('resource_id')
    u_ref = item.get('customer_reference')
    if u_ref and u_ref in uid_to_ids:
        if u_ref not in ev_user_records: ev_user_records[u_ref] = []
        res_allow = item.get('restore_allowed', False)
        ev_user_records[u_ref].append(('backup_service', rid, 'evidence_92', {'is_restore_blocked': not res_allow, 'has_restore_risk': res_allow}))

for item in exports92.get('search_service', {}).get('index_queries', []):
    rid = item.get('resource_id')
    q = item.get('query', '')
    uid = id_to_uid.get(q.lower())
    if uid:
        if uid not in ev_user_records: ev_user_records[uid] = []
        hits = item.get('hits', {}).get('total', 0)
        ev_user_records[uid].append(('search_service', rid, 'evidence_92', {'is_present': (hits > 0)}))

for item in exports92.get('export_service', {}).get('exports', []):
    rid = item.get('resource_id')
    em = item.get('owner_email', '')
    uid = id_to_uid.get(em.lower())
    if uid:
        if uid not in ev_user_records: ev_user_records[uid] = []
        ev_user_records[uid].append(('export_service', rid, 'evidence_92', {'is_present': True}))

print(f"Total users indexed in ev92: {len(ev_user_records)}")
