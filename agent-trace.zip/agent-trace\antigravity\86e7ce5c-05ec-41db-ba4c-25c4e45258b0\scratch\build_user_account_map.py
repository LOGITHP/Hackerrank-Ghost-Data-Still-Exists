import pandas as pd
import json
import glob
import re
import sqlite3

identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')

# Build mapping of user_id -> primary account resource
# Where is this mapping stored in evidence?
# 1. SQL customer_profiles or customer_data_primary
# 2. JSON customer_profiles
# 3. Logs

user_to_account = {}

# Check all SQL files
for f in glob.glob('dataset/evidence/databases/*.sql'):
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        sql = fp.read()
    # Match patterns like: INSERT INTO "customer_profiles..." VALUES('account_...', 'user_...'
    # or record_json with resource_id and user_id / customer_reference
    matches = re.findall(r"VALUES\('(account_\w+)','(user_\w+)'", sql)
    for acc, uid in matches:
        user_to_account[uid] = acc
    # Also in JSON dumps inside SQL
    matches_json = re.findall(r'"resource_id"\s*:\s*"(account_\w+)".*?"(?:user_id|customer_reference)"\s*:\s*"(user_\w+)"', sql)
    for acc, uid in matches_json:
        user_to_account[uid] = acc

# Check all JSON files
for f in glob.glob('dataset/evidence/records/*.json'):
    with open(f, 'r', encoding='utf-8') as fp:
        try:
            data = json.load(fp)
        except Exception:
            continue
    def extract_acc(obj):
        if isinstance(obj, dict):
            rid = obj.get('resource_id')
            uid = obj.get('user_id') or obj.get('customer_reference') or obj.get('subject_reference')
            if rid and rid.startswith('account_') and uid and uid.startswith('user_'):
                user_to_account[uid] = rid
            for v in obj.values():
                extract_acc(v)
        elif isinstance(obj, list):
            for it in obj:
                extract_acc(it)
    extract_acc(data)

print(f"Total user_to_account mapped: {len(user_to_account)} / {len(identities)}")
print("Sample mappings:", list(user_to_account.items())[:15])
