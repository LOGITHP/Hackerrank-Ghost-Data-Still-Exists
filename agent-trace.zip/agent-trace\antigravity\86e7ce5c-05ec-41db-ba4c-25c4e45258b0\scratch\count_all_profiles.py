import glob
import json

bundles = sorted(glob.glob('dataset/evidence/records/customer_data_snapshot_bundle_*.json'))
print(f"Total snapshot bundles: {len(bundles)}")

total_profiles = 0
all_profile_map = {}

for b in bundles:
    with open(b, 'r', encoding='utf-8') as fp:
        d = json.load(fp)
    snapshots = d.get('snapshots', [])
    for s in snapshots:
        store = s.get('data_store')
        coll = s.get('collection')
        records = s.get('records', [])
        if store == 'account_service' and coll == 'customer_profiles':
            for r in records:
                rid = r.get('resource_id')
                uid = r.get('customer_reference') or r.get('user_id')
                email = r.get('email')
                if rid:
                    all_profile_map[rid] = (uid, email, b)
                    total_profiles += 1

print(f"Total account profiles found across all snapshot bundles: {len(all_profile_map)}")
print("Sample profiles:", list(all_profile_map.items())[:10])
