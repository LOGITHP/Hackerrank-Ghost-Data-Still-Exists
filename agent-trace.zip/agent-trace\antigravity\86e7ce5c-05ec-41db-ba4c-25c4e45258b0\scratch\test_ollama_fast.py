import urllib.request
import json
import time

t0 = time.time()
payload = {
    "model": "qwen3.5:4B",
    "messages": [
        {"role": "user", "content": 'Respond ONLY with JSON: {"is_deletion": true/false}. Request: "Please delete my account."'}
    ],
    "options": {
        "num_ctx": 2048,
        "num_predict": 60,
        "temperature": 0.0
    },
    "stream": False
}
req = urllib.request.Request(
    'http://localhost:11434/api/chat',
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'}
)
resp = urllib.request.urlopen(req, timeout=30)
res = json.loads(resp.read().decode('utf-8'))
print(f"Elapsed: {time.time()-t0:.2f}s")
print("Response:", res.get('message', {}).get('content'))
print("eval_count:", res.get('eval_count'), "prompt_eval_count:", res.get('prompt_eval_count'))
