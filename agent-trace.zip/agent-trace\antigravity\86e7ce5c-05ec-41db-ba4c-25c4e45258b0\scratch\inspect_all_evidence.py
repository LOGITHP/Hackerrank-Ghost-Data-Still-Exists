import glob
import json
import re

print("=== INSPECTING JSON FILES ===")
json_files = sorted(glob.glob('dataset/evidence/records/*.json'))
for f in json_files:
    with open(f, 'r', encoding='utf-8') as fp:
        try:
            data = json.load(fp)
            keys = list(data.keys())
            print(f"{f}: keys={keys}")
        except Exception as e:
            print(f"Error {f}: {e}")

print("\n=== INSPECTING LOG FILES ===")
log_files = sorted(glob.glob('dataset/evidence/logs/*.log'))
for f in log_files:
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        first_line = fp.readline().strip()
        print(f"{f}: first_line={first_line[:90]}")
