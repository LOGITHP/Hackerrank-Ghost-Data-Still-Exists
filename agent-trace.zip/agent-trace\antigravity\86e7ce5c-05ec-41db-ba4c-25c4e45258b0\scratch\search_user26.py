import os
import json
import glob
import re
import sqlite3
import pypdf

user_target = 'user_26'
email_target = 'almeida.mariana@gmail.com'

print(f"=== Searching for {user_target} / {email_target} across all evidence files ===")

# 1. JSON records
for f in glob.glob('dataset/evidence/records/*.json'):
    with open(f, 'r', encoding='utf-8') as fp:
        content = fp.read()
    if user_target in content or email_target in content:
        print(f"[JSON] {f}")
        data = json.loads(content)
        # Search objects
        def search_obj(obj, path=""):
            if isinstance(obj, dict):
                has_user = any(str(v).lower() in [user_target, email_target] for v in obj.values())
                if has_user:
                    print(f"   found record: {obj.get('resource_id')} | sys={obj.get('data_store')} | keys={list(obj.keys())} | val={obj}")
                for k, v in obj.items():
                    search_obj(v, path + "." + k)
            elif isinstance(obj, list):
                for item in obj:
                    search_obj(item, path + "[]")
        search_obj(data)

# 2. SQL
for f in glob.glob('dataset/evidence/databases/*.sql'):
    with open(f, 'r', encoding='utf-8') as fp:
        content = fp.read()
    if user_target in content or email_target in content:
        print(f"[SQL] {f}")
        for line in content.splitlines():
            if user_target in line or email_target in line:
                print(f"   line: {line[:120]}")

# 3. Logs
for f in glob.glob('dataset/evidence/logs/*.log'):
    with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
        for line in fp:
            if user_target in line or email_target in line:
                print(f"[LOG] {f}: {line.strip()[:120]}")

# 4. Text
for f in glob.glob('dataset/evidence/records/*.txt'):
    with open(f, 'r', encoding='utf-8') as fp:
        for line in fp:
            if user_target in line or email_target in line:
                print(f"[TXT] {f}: {line.strip()[:120]}")
