import pandas as pd
import json

gt = pd.read_csv('dataset/sample_output.csv')
for cid in ['case_01', 'case_02', 'case_03', 'case_04', 'case_25', 'case_26', 'case_27', 'case_28', 'case_31']:
    r = gt[gt['case_id'] == cid].iloc[0]
    steps = json.loads(r['steps_json'])
    rids = [(s['system_id'], s['resource_id'], s['operation'], s['state'], s.get('evidence_id')) for s in steps]
    print(f"{cid} ({r['deletion_status']}): {rids}\n")
