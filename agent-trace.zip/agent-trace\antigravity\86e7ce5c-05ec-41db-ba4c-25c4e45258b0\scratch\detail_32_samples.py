import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
evidence_files = pd.read_csv('dataset/evidence_files.csv')
ev_map = dict(zip(evidence_files['file_id'], evidence_files['file_path']))

for i, row in sample_out.iterrows():
    cid = row['case_id']
    st = row['deletion_status']
    steps = json.loads(row['steps_json'])
    evs = set(s['evidence_id'] for s in steps if s['evidence_id'])
    ev_files = [f"{e} ({ev_map.get(e)})" for e in evs]
    rids = [f"{s['resource_id']}:{s['operation']}" for s in steps]
    print(f"{cid} | {st:12} | Ev: {ev_files} | Steps: {rids}")
