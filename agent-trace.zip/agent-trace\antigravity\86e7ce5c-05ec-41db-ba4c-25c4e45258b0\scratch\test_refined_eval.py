import pandas as pd
import json

sample_out = pd.read_csv('dataset/sample_output.csv')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
ef = pd.read_csv('dataset/evidence_files.csv')
ef['dt'] = pd.to_datetime(ef['captured_at'])

# Check captured_at for every evidence cited in sample_output vs requested_at
for i, r in sample_out.iterrows():
    cid = r['case_id']
    req = samples[samples['case_id'] == cid].iloc[0]
    req_at = pd.to_datetime(req['requested_at'])
    aud_at = pd.to_datetime(req['audit_at'])
    
    steps = json.loads(r['steps_json'])
    for s in steps:
        ev_id = s.get('evidence_id')
        if ev_id:
            row = ef[ef['file_id'] == ev_id].iloc[0]
            cap_dt = row['dt']
            is_after_req = (cap_dt >= req_at - pd.Timedelta(days=1))
            if not is_after_req:
                print(f"ALERT: {cid} cited {ev_id} captured at {cap_dt} before req_at {req_at}!")
print("Checked all sample evidence citations against requested_at.")
