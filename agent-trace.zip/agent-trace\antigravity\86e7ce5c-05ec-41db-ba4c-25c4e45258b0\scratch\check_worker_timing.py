import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')
activity['dt'] = pd.to_datetime(activity['event_time'])

for i, row in sample_out.iterrows():
    cid = row['case_id']
    req = samples[samples['case_id'] == cid].iloc[0]
    rep_at = pd.to_datetime(req['reported_at'])
    steps = json.loads(row['steps_json'])
    gt_rids = set(s['resource_id'] for s in steps)
    
    # Filter activities for gt_rids
    m_acts = activity[activity['resource_id'].isin(gt_rids) & (activity['source_system'] == 'deletion_worker')]
    
    diffs = []
    for _, a in m_acts.iterrows():
        delta = (rep_at - a['dt']).total_seconds()
        diffs.append((a['resource_id'], a['target_system'], a['event_type'], f"{delta:.0f}s before rep_at"))
        
    print(f"\n{cid} ({req['reported_status']}): rep_at={req['reported_at']}")
    for d in diffs:
        print(f"   {d[0]:15} | {d[1]:20} | {d[2]:15} | {d[3]}")
