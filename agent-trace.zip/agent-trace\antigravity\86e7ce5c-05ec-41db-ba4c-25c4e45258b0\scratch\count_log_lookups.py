import glob
import re

logs = sorted(glob.glob('dataset/evidence/logs/resource_lookup_trace_*.log'))
print(f"Total resource lookup trace logs: {len(logs)}")

lookups = []
for l in logs:
    with open(l, 'r', encoding='utf-8') as fp:
        for line in fp:
            if 'event=profile_lookup_started' in line:
                m = re.search(r'resource_id=(\w+)\s+lookup_key=([^\s]+)', line)
                if m:
                    lookups.append((m.group(1), m.group(2), l))

print(f"Total profile lookups in resource_lookup_trace: {len(lookups)}")
print("Sample lookups:", lookups[:10])
