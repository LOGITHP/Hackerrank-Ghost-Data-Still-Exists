import pandas as pd
import re

df = pd.read_csv('dataset/deletion_requests.csv')

# Common deletion terms across English, French, Spanish, German, Italian, Portuguese, Japanese, Korean, Chinese
del_patterns = [
    r'\bdelet\w*', r'\beras\w*', r'\bremov\w*', r'\bclos\w*', r'\bpurge\w*', r'\bforget\w*',
    r'suppression', r'supprimer', r'effacer',
    r'eliminar', r'borrar', r'exclus[aã]o',
    r'l[oö]schen', r'entfernen',
    r'cancellare', r'eliminare',
    r'削除', r'消去',
    r'삭제', r'탈퇴',
    r'注销', r'删除'
]
combined_pat = re.compile('|'.join(del_patterns), re.IGNORECASE)

non_deletion = []
for i, r in df.iterrows():
    text = r['request_text']
    if not combined_pat.search(text):
        non_deletion.append((r['case_id'], r['email'], text))

print(f"Total requests without obvious deletion keywords: {len(non_deletion)}")
for item in non_deletion:
    print(item[0], item[1], item[2])
