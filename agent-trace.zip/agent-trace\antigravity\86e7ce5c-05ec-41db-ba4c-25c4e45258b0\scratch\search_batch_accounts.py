import os, json, glob, re

for acc in ['account_5684', 'account_3866', 'account_5482', 'account_7012', 'account_3136', 'account_5334']:
    print(f"\n==================== Searching for {acc} ====================")
    for f in glob.glob('dataset/evidence/records/*.json') + glob.glob('dataset/evidence/records/*.txt') + glob.glob('dataset/evidence/logs/*.log'):
        with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
            for lno, line in enumerate(fp, 1):
                if acc in line:
                    print(f"  {f}:{lno}: {line.strip()[:110]}")
    for f in glob.glob('dataset/evidence/databases/*.sql'):
        with open(f, 'r', encoding='utf-8', errors='ignore') as fp:
            for lno, line in enumerate(fp, 1):
                if acc in line:
                    print(f"  {f}:{lno}: {line.strip()[:110]}")
