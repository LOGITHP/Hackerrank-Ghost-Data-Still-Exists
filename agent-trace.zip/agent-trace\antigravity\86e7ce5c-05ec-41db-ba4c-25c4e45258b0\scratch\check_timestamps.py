import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
ev_files = pd.read_csv('dataset/evidence_files.csv')
ev_caps = dict(zip(ev_files['file_id'], ev_files['captured_at']))

for i, row in sample_out.iterrows():
    cid = row['case_id']
    req = samples[samples['case_id'] == cid].iloc[0]
    audit_at = req['audit_at']
    steps = json.loads(row['steps_json'])
    ev_ids = set(s['evidence_id'] for s in steps if s['evidence_id'])
    print(f"\n{cid}: audit_at={audit_at}")
    for ev in sorted(ev_ids):
        cap = ev_caps.get(ev)
        valid = (cap <= audit_at) if cap else False
        print(f"  Cited {ev}: captured_at={cap} <= audit_at? {valid}")
