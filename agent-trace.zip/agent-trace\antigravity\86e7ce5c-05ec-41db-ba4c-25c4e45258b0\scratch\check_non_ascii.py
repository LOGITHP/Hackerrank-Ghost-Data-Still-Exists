import pandas as pd

df = pd.read_csv('dataset/deletion_requests.csv')

non_ascii = []
for i, r in df.iterrows():
    if not r['request_text'].isascii():
        non_ascii.append((r['case_id'], r['email'], r['request_text']))

print(f"Total non-ASCII requests: {len(non_ascii)}")
# Print unique patterns
unique_texts = set(x[2] for x in non_ascii)
print(f"Unique non-ASCII texts: {len(unique_texts)}")
for t in sorted(unique_texts):
    print("--- TEXT ---")
    print(t[:150])
