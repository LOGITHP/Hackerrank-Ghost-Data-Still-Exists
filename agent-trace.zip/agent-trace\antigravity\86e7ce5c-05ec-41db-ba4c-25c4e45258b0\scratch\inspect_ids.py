import pandas as pd
import json
import glob
import os

identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')

def get_user_all_ids(email):
    # find user_id
    uid = None
    r = identities[identities['email'].str.lower() == email.lower()]
    if len(r) > 0:
        uid = r.iloc[0]['user_id']
    else:
        h = audit_log[(audit_log['old_value'].str.lower() == email.lower()) | (audit_log['new_value'].str.lower() == email.lower())]
        if len(h) > 0:
            uid = h.iloc[0]['user_id']
    
    if not uid:
        return None, set()
    
    # collect all identifiers
    ids = {uid, email.lower()}
    u_row = identities[identities['user_id'] == uid]
    if len(u_row) > 0:
        row = u_row.iloc[0]
        for f in ['email', 'phone', 'email_hash', 'name']:
            if pd.notna(row[f]):
                ids.add(str(row[f]).lower())
    
    for _, a in audit_log[audit_log['user_id'] == uid].iterrows():
        if pd.notna(a['old_value']): ids.add(str(a['old_value']).lower())
        if pd.notna(a['new_value']): ids.add(str(a['new_value']).lower())
        
    return uid, ids

# For case_03, case_04, case_09, case_11
for cid in ['case_03', 'case_04', 'case_09', 'case_11', 'case_31', 'case_32']:
    req = samples[samples['case_id'] == cid].iloc[0]
    out = sample_out[sample_out['case_id'] == cid].iloc[0]
    uid, ids = get_user_all_ids(req['email'])
    print(f"\n==================== {cid} (UID: {uid}) ====================")
    print(f"IDs: {ids}")
    gt_steps = json.loads(out['steps_json'])
    for s in gt_steps:
        print(f"  GT: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | {s['evidence_id']}")
