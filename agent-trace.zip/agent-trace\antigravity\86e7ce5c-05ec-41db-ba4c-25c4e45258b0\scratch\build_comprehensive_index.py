import pandas as pd
import json
import glob
import re

identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')

# Build comprehensive user lookup
# uid -> set of all identifiers (lowercase)
user_all_ids = {}
id_to_uid = {}

for _, r in identities.iterrows():
    uid = r['user_id']
    if uid not in user_all_ids:
        user_all_ids[uid] = set()
    user_all_ids[uid].add(uid.lower())
    for f in ['email', 'phone', 'email_hash', 'name']:
        val = r[f]
        if pd.notna(val):
            s = str(val).lower()
            user_all_ids[uid].add(s)
            id_to_uid[s] = uid

for _, a in audit_log.iterrows():
    uid = a['user_id']
    if uid not in user_all_ids:
        user_all_ids[uid] = set()
    user_all_ids[uid].add(uid.lower())
    for f in ['old_value', 'new_value']:
        val = a[f]
        if pd.notna(val):
            s = str(val).lower()
            user_all_ids[uid].add(s)
            id_to_uid[s] = uid

print(f"Total indexed users: {len(user_all_ids)}")
print(f"Total identifier mappings: {len(id_to_uid)}")

# Test resolving sample requests
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
unresolved = 0
for _, r in samples.iterrows():
    em = r['email'].lower()
    uid = id_to_uid.get(em)
    if not uid:
        unresolved += 1
print(f"Samples unresolved: {unresolved} / {len(samples)}")

# Test resolving main deletion requests
del_req = pd.read_csv('dataset/deletion_requests.csv')
unresolved_main = 0
for _, r in del_req.iterrows():
    em = r['email'].lower()
    uid = id_to_uid.get(em)
    if not uid:
        unresolved_main += 1
print(f"Main deletion requests unresolved: {unresolved_main} / {len(del_req)}")
