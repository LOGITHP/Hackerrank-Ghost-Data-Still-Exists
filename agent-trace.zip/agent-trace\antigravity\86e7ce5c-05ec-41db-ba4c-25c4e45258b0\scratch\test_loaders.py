import pandas as pd
import json
import glob
import os
import re
import sqlite3
import pypdf

# Load evidence manifest
manifest = pd.read_csv('dataset/evidence_files.csv')
file_to_ev = dict(zip(manifest['file_path'], manifest['file_id']))
ev_to_cap = dict(zip(manifest['file_id'], manifest['captured_at']))

print(f"Total manifest entries: {len(manifest)}")

# Test parsing records/*.json
json_records = 0
for f in glob.glob('dataset/evidence/records/*.json'):
    ev_id = file_to_ev.get(f.replace('\\', '/'))
    with open(f, 'r', encoding='utf-8') as fp:
        d = json.load(fp)
        json_records += 1

print(f"Loaded {json_records} JSON evidence files.")

# Test parsing documents/*.pdf
pdf_records = 0
for f in glob.glob('dataset/evidence/documents/*.pdf'):
    ev_id = file_to_ev.get(f.replace('\\', '/'))
    reader = pypdf.PdfReader(f)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    pdf_records += 1
print(f"Loaded {pdf_records} PDF files.")

# Test parsing databases/*.sql
sql_records = 0
for f in glob.glob('dataset/evidence/databases/*.sql'):
    ev_id = file_to_ev.get(f.replace('\\', '/'))
    sql_records += 1
print(f"Checked {sql_records} SQL files.")

# Test parsing logs/*.log
log_records = 0
for f in glob.glob('dataset/evidence/logs/*.log'):
    ev_id = file_to_ev.get(f.replace('\\', '/'))
    log_records += 1
print(f"Checked {log_records} LOG files.")
