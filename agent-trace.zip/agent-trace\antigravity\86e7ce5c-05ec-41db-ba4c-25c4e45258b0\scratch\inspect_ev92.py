import json

with open('dataset/evidence/records/service_resource_export_20260915_114455.json', 'r') as fp:
    d = json.load(fp)

exports = d.get('service_exports', {})
for s_name, s_val in exports.items():
    print(f"System: {s_name} (type: {type(s_val)})")
    if isinstance(s_val, dict):
        for k2, v2 in s_val.items():
            print(f"   sub: {k2} (len: {len(v2) if isinstance(v2, list) else type(v2)})")
            if isinstance(v2, list) and len(v2) > 0:
                print(f"       sample: {v2[0]}")
    elif isinstance(s_val, list):
        print(f"   len: {len(s_val)}")
        if len(s_val) > 0:
            print(f"   sample: {s_val[0]}")
