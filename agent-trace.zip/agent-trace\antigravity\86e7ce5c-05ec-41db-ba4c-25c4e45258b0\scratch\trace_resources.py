import pandas as pd
import json
import glob
import os

sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')
identities = pd.read_csv('dataset/user_identities.csv')

# Collect all resources from sample_output
all_res = {}
for i, row in sample_out.iterrows():
    case_id = row['case_id']
    steps = json.loads(row['steps_json'])
    for s in steps:
        rid = s['resource_id']
        sys = s['system_id']
        op = s['operation']
        st = s['state']
        ev = s['evidence_id']
        if rid not in all_res:
            all_res[rid] = []
        all_res[rid].append((case_id, sys, op, st, ev))

print(f"Total unique resources in sample_output: {len(all_res)}")

# Check where each resource appears in system_activity
in_activity = 0
not_in_activity = []
for rid in all_res:
    acts = activity[activity['resource_id'] == rid]
    if len(acts) > 0:
        in_activity += 1
    else:
        not_in_activity.append(rid)

print(f"Resources found in system_activity: {in_activity} / {len(all_res)}")
print(f"Resources NOT in system_activity: {len(not_in_activity)}")
print("Sample NOT in system_activity:", not_in_activity[:20])
