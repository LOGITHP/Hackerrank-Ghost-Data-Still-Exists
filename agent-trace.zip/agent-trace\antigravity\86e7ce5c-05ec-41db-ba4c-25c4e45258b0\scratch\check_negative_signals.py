import pandas as pd
import re

df = pd.read_csv('dataset/deletion_requests.csv', encoding='utf-8')

# Let's inspect cases that might NOT be deletion:
# Requests that ask to keep account, or don't mention delete/remove/erase/close/suppression/etc.
non_del_list = []
for i, r in df.iterrows():
    text = r['request_text']
    cid = r['case_id']
    # Check if text contains negative indicators like "keep the account", "leave the account", "continue using", etc.
    low = text.lower()
    has_negative = any(neg in low for neg in [
        'leave the account active',
        'keep the account',
        'continue using',
        'leave my profile',
        'do not delete',
        'keep my account'
    ])
    if has_negative:
        non_del_list.append((cid, text, "NEGATIVE_SIGNAL"))

print(f"Total with negative signals: {len(non_del_list)}")
for c, t, reason in non_del_list:
    print(f"[{c}] -> {t}")
