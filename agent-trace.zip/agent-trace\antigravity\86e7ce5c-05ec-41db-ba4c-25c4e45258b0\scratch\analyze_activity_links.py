import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')

# Let's map each sample case's ground truth resources back to system_activity
# to see why those exact resources were selected for that user!
for i, r in sample_out.iterrows():
    cid = r['case_id']
    steps = json.loads(r['steps_json'])
    rids = set(s['resource_id'] for s in steps)
    req = samples[samples['case_id'] == cid].iloc[0]
    
    # check activities for these rids
    acts = activity[activity['resource_id'].isin(rids)]
    print(f"\n{cid} ({len(rids)} resources):")
    for _, a in acts.iterrows():
        print(f"  {a['activity_id']} | {a['event_time']} | {a['event_type']} | {a['source_system']}->{a['target_system']} | {a['resource_id']} | {a['details']}")
