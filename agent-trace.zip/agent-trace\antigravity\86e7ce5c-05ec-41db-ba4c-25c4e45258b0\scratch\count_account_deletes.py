import pandas as pd

activity = pd.read_csv('dataset/system_activity.csv')
acc_deletes = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service') & (activity['event_type'] == 'DELETE_RECORD')]
print(f"Total account_service DELETE_RECORD events by deletion_worker: {len(acc_deletes)}")
print(f"Unique account resources: {acc_deletes['resource_id'].nunique()}")
