import pandas as pd

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
del_req = pd.read_csv('dataset/deletion_requests.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Build id -> uid
id_to_uid = {}
for _, r in identities.iterrows():
    uid = r['user_id']
    id_to_uid[r['email'].lower()] = uid
    if pd.notna(r['phone']): id_to_uid[str(r['phone']).lower()] = uid
for _, a in audit_log.iterrows():
    uid = a['user_id']
    if pd.notna(a['old_value']): id_to_uid[str(a['old_value']).lower()] = uid
    if pd.notna(a['new_value']): id_to_uid[str(a['new_value']).lower()] = uid

activity['dt'] = pd.to_datetime(activity['event_time'])
worker_acc = activity[(activity['source_system'] == 'deletion_worker') & (activity['target_system'] == 'account_service') & (activity['event_type'] == 'DELETE_RECORD')].copy()

# For each of the 32 sample cases, find the worker account delete event closest to reported_at (within +- 2 hours)
# and compare it to the ground truth account resource!
matches = 0
for i, r in sample_out.iterrows():
    cid = r['case_id']
    req = samples[samples['case_id'] == cid].iloc[0]
    rep_at = pd.to_datetime(req['reported_at'])
    
    # Ground truth account rid
    import json
    steps = json.loads(r['steps_json'])
    acc_rids = [s['resource_id'] for s in steps if s['system_id'] == 'account_service']
    gt_acc = acc_rids[0] if acc_rids else None
    
    # Candidate from worker_acc
    worker_acc['delta'] = (worker_acc['dt'] - rep_at).abs()
    closest = worker_acc.sort_values('delta').iloc[0]
    pred_acc = closest['resource_id']
    delta_s = closest['delta'].total_seconds()
    
    is_match = (gt_acc == pred_acc)
    if is_match:
        matches += 1
    print(f"{cid}: gt={gt_acc} pred={pred_acc} delta={delta_s:.0f}s match={is_match}")

print(f"\nTotal matches: {matches} / {len(sample_out)}")
