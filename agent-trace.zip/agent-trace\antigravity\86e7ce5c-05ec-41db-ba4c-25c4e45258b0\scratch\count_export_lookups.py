import glob
import json

exports = sorted(glob.glob('dataset/evidence/records/service_resource_export_*.json'))
print(f"Total service resource exports: {len(exports)}")

all_acc_lookups = {}
for e in exports:
    with open(e, 'r', encoding='utf-8') as fp:
        d = json.load(fp)
    se = d.get('service_exports', {})
    acc_service = se.get('account_service', {})
    for pl in acc_service.get('profile_lookups', []):
        rid = pl.get('resource_id')
        code = pl.get('status_code')
        prof = pl.get('profile') or {}
        email = prof.get('email')
        uid = prof.get('customer_reference')
        all_acc_lookups[rid] = (code, email, uid, e)

print(f"Total account profile lookups across all service resource exports: {len(all_acc_lookups)}")
print("Sample profile lookups:", list(all_acc_lookups.items())[:10])
