import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
ef = pd.read_csv('dataset/evidence_files.csv')
ef['dt'] = pd.to_datetime(ef['captured_at'])

for i, r in samples.iterrows():
    cid = r['case_id']
    aud_dt = pd.to_datetime(r['audit_at'])
    admissible = ef[ef['dt'] <= aud_dt].sort_values('dt', ascending=False)
    latest_file = admissible.iloc[0]['file_id']
    latest_time = admissible.iloc[0]['captured_at']
    
    gt_row = sample_out[sample_out['case_id'] == cid].iloc[0]
    gt_steps = json.loads(gt_row['steps_json'])
    gt_evs = set(s.get('evidence_id') for s in gt_steps if s.get('evidence_id'))
    
    print(f"{cid}: audit_at={r['audit_at']} | GT evs={gt_evs} | latest_file={latest_file} ({latest_time})")
