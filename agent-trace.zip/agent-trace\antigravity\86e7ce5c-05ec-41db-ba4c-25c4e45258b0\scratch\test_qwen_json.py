import urllib.request
import json
import time

t0 = time.time()
payload = {
    "model": "qwen3.5:4B",
    "messages": [
        {"role": "system", "content": "You are a concise intent classifier. Return ONLY a JSON object: {\"is_deletion\": true} or {\"is_deletion\": false}."},
        {"role": "user", "content": 'Request: "Please delete my account and personal data."'}
    ],
    "options": {
        "num_ctx": 2048,
        "num_predict": 300,
        "temperature": 0.0
    },
    "stream": False
}
req = urllib.request.Request(
    'http://localhost:11434/api/chat',
    data=json.dumps(payload).encode('utf-8'),
    headers={'Content-Type': 'application/json'}
)
resp = urllib.request.urlopen(req, timeout=30)
res = json.loads(resp.read().decode('utf-8'))
print(f"Elapsed: {time.time()-t0:.2f}s")
msg = res.get('message', {})
print("Raw Content:", repr(msg.get('content')))
print("eval_count:", res.get('eval_count'), "prompt_eval_count:", res.get('prompt_eval_count'))
