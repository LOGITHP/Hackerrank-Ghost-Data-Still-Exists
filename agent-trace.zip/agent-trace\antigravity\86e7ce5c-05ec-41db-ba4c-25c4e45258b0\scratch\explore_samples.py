import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')

for i, row in sample_out.head(10).iterrows():
    case_id = row['case_id']
    status = row['deletion_status']
    steps = json.loads(row['steps_json'])
    req = samples[samples['case_id'] == case_id].iloc[0]
    email = req['email']
    audit_at = req['audit_at']
    print(f"=== {case_id} ({status}) email={email} audit_at={audit_at} ===")
    for s in steps:
        print(f"   step {s['step_no']}: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | {s['evidence_id']}")
