import sqlite3
import re

for f in ['dataset/evidence/databases/customer_data_inventory_20260916.sql', 'dataset/evidence/databases/customer_data_read_replica_20260921.sql']:
    conn = sqlite3.connect(':memory:')
    with open(f, 'r', encoding='utf-8') as fp:
        sql = fp.read()
    conn.executescript(sql)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row[0] for row in cur.fetchall()]
    print(f"=== {f} ===")
    for t in tables:
        cur.execute(f"PRAGMA table_info({t});")
        cols = [c[1] for c in cur.fetchall()]
        cur.execute(f"SELECT COUNT(*) FROM {t};")
        cnt = cur.fetchone()[0]
        print(f"  Table {t} ({cnt} rows): cols={cols}")
        if cnt > 0:
            cur.execute(f"SELECT * FROM {t} LIMIT 1;")
            print(f"    Sample: {cur.fetchone()}")
    conn.close()
