import pandas as pd
import json
import os
import glob
import re

# Load all participant datasets
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')
rules = pd.read_csv('dataset/deletion_rules.csv')
evidence_files = pd.read_csv('dataset/evidence_files.csv')

print(f"Loaded {len(samples)} samples, {len(sample_out)} sample outputs.")

# Test exact matching of all 32 sample cases
for i, r in sample_out.iterrows():
    cid = r['case_id']
    st = r['deletion_status']
    steps = json.loads(r['steps_json'])
    print(f"{cid}: status={st}, num_steps={len(steps)}")
