import glob
import re

logs = sorted(glob.glob('dataset/evidence/logs/*.log'))

all_log_matches = []
for l in logs:
    with open(l, 'r', encoding='utf-8', errors='ignore') as fp:
        for lno, line in enumerate(fp, 1):
            # check for resource_id=
            r_match = re.search(r'\bresource_id=([a-zA-Z0-9_-]+)', line)
            # check for email
            e_match = re.search(r'[\w\.-]+@[\w\.-]+', line)
            # check for user_id
            u_match = re.search(r'\b(user_\d+)\b', line)
            if r_match and (e_match or u_match):
                all_log_matches.append((r_match.group(1), e_match.group(0) if e_match else None, u_match.group(1) if u_match else None, l))

print(f"Total matched (resource_id, email/user_id) lines in all logs: {len(all_log_matches)}")
print("Sample log matches:", all_log_matches[:10])
