import pandas as pd
act = pd.read_csv('dataset/system_activity.csv')
for i in range(3425, 3445):
    r = act.iloc[i]
    print(f"{r['activity_id']} | {r['event_time']} | {r['source_system']} -> {r['target_system']} | {r['event_type']} | {r['resource_id']} | {r['reported_result']} | {r['details']}")
