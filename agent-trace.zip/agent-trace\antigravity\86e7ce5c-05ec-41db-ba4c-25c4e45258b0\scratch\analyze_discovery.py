import pandas as pd
import json

samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Let's see: How are resources in sample_output discovered?
# For each sample case, let's see where its resources are mentioned:
# 1. In system_activity details?
# 2. In system_activity resource_id?
# 3. In evidence files?

results = []
for i, row in sample_out.iterrows():
    cid = row['case_id']
    steps = json.loads(row['steps_json'])
    rids = [s['resource_id'] for s in steps]
    req = samples[samples['case_id'] == cid].iloc[0]
    email = req['email']
    
    # User ID
    uid = None
    u = identities[identities['email'].str.lower() == email.lower()]
    if len(u) > 0:
        uid = u.iloc[0]['user_id']
    else:
        h = audit_log[(audit_log['old_value'].str.lower() == email.lower()) | (audit_log['new_value'].str.lower() == email.lower())]
        if len(h) > 0:
            uid = h.iloc[0]['user_id']
            
    # Check where each rid appears
    for s in steps:
        rid = s['resource_id']
        sys = s['system_id']
        phase = s['phase']
        op = s['operation']
        st = s['state']
        ev = s['evidence_id']
        
        # Check system_activity
        act_rows = activity[activity['resource_id'] == rid]
        act_types = list(act_rows['event_type'].unique()) if len(act_rows) > 0 else []
        act_sources = list(act_rows['source_system'].unique()) if len(act_rows) > 0 else []
        act_results = list(act_rows['reported_result'].unique()) if len(act_rows) > 0 else []
        
        results.append({
            'case_id': cid,
            'uid': uid,
            'email': email,
            'resource_id': rid,
            'system_id': sys,
            'phase': phase,
            'operation': op,
            'state': st,
            'evidence_id': ev,
            'in_activity': len(act_rows) > 0,
            'act_types': act_types,
            'act_results': act_results
        })

df_res = pd.DataFrame(results)
print(df_res.head(25).to_string())
print("\nUnique operations:", df_res['operation'].value_counts())
