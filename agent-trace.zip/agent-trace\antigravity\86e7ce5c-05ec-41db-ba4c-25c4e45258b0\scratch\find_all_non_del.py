import pandas as pd
import re

df = pd.read_csv('dataset/deletion_requests.csv')

non_del_signals = [
    r'leave the account active',
    r'keep the account',
    r'continue using',
    r'do not delete',
    r'download my',
    r'export my',
    r'copy of last year',
    r'change the email',
    r'update my',
    r'replace it with the new one',
    r'opt[- ]out',
    r'unsubscribe',
    r'marketing email',
    r'newsletter'
]

flagged = []
for i, r in df.iterrows():
    t = r['request_text'].lower()
    for sig in non_del_signals:
        if re.search(sig, t):
            flagged.append((r['case_id'], r['email'], sig, r['request_text']))
            break

print(f"Total flagged non-deletion candidates: {len(flagged)}")
for item in flagged:
    print(f"{item[0]}: matched '{item[2]}' -> {item[3]}")
