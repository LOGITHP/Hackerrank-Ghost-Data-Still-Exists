import pandas as pd
import json

sample_out = pd.read_csv('dataset/sample_output.csv')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
ev_files = pd.read_csv('dataset/evidence_files.csv')

for _, r in sample_out.head(10).iterrows():
    cid = r['case_id']
    st = r['deletion_status']
    steps = json.loads(r['steps_json'])
    req = samples[samples['case_id'] == cid].iloc[0]
    print(f"=== {cid} ({st}) audit_at={req['audit_at']} ===")
    for s in steps:
        ev_id = s.get('evidence_id')
        ev_cap = ''
        row = ev_files[ev_files['file_id'] == ev_id]
        if len(row) > 0:
            ev_cap = row['captured_at'].iloc[0]
        print(f"  [{s['phase']}] sys={s['system_id']:18} rid={s['resource_id']:16} op={s['operation']:25} st={s['state']:10} ev={ev_id} (cap={ev_cap})")
