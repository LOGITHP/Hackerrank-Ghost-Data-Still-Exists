import pandas as pd
import json
import glob
import re

identities = pd.read_csv('dataset/user_identities.csv')
audit_log = pd.read_csv('dataset/user_audit_log.csv')
samples = pd.read_csv('dataset/sample_deletion_requests.csv')
sample_out = pd.read_csv('dataset/sample_output.csv')
activity = pd.read_csv('dataset/system_activity.csv')

# Build mapping of identifier -> uid
user_all_ids = {}
id_to_uid = {}
for _, r in identities.iterrows():
    uid = r['user_id']
    if uid not in user_all_ids: user_all_ids[uid] = set()
    user_all_ids[uid].add(uid.lower())
    for f in ['email', 'phone', 'email_hash', 'name']:
        if pd.notna(r[f]):
            s = str(r[f]).lower()
            user_all_ids[uid].add(s)
            id_to_uid[s] = uid
for _, a in audit_log.iterrows():
    uid = a['user_id']
    if uid not in user_all_ids: user_all_ids[uid] = set()
    user_all_ids[uid].add(uid.lower())
    for f in ['old_value', 'new_value']:
        if pd.notna(a[f]):
            s = str(a[f]).lower()
            user_all_ids[uid].add(s)
            id_to_uid[s] = uid

# Let's inspect where the ground truth resources appear in the entire dataset for sample cases!
# For each sample case, let's find ALL evidence records that contain ANY identifier of that user!
def scan_evidence_for_ids(target_ids):
    found = []
    # 1. JSON
    for f in glob.glob('dataset/evidence/records/*.json'):
        with open(f, 'r', encoding='utf-8') as fp:
            try: d = json.load(fp)
            except: continue
        def rec(o):
            if isinstance(o, dict):
                has = any(str(v).lower() in target_ids for v in o.values())
                if has:
                    found.append((f, o))
                for v in o.values(): rec(v)
            elif isinstance(o, list):
                for it in o: rec(it)
        rec(d)
    # 2. Text / Logs / SQL lines
    for p in glob.glob('dataset/evidence/records/*.txt') + glob.glob('dataset/evidence/logs/*.log'):
        with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
            for line in fp:
                low = line.lower()
                if any(t in low for t in target_ids):
                    found.append((p, line.strip()))
    return found

for cid in ['case_01', 'case_03', 'case_05', 'case_06', 'case_10', 'case_11', 'case_16', 'case_26', 'case_31']:
    req = samples[samples['case_id'] == cid].iloc[0]
    out = sample_out[sample_out['case_id'] == cid].iloc[0]
    uid = id_to_uid[req['email'].lower()]
    u_ids = user_all_ids[uid]
    gt_steps = json.loads(out['steps_json'])
    gt_rids = set(s['resource_id'] for s in gt_steps)
    ev_matches = scan_evidence_for_ids(u_ids)
    print(f"\n{cid} (uid={uid}): GT={gt_rids}")
    print(f"  Total evidence matches: {len(ev_matches)}")
    matched_rids = set()
    for f, item in ev_matches:
        if isinstance(item, dict):
            rid = item.get('resource_id')
            if rid: matched_rids.add(rid)
        else:
            # find resource_ids in line
            r_in_line = re.findall(r'\b(account_\w+|search_\w+|support_\w+|data_flow_\w+|backup_\w+|export_\w+|tombstone_\w+|analytics_\w+|audit_record_\w+)\b', item)
            matched_rids.update(r_in_line)
    print(f"  Matched RIDs from evidence: {matched_rids}")
    print(f"  Missing from evidence: {gt_rids - matched_rids}")
